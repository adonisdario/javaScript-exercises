function somaPA() {
    var a1x = document.getElementById('txta1')
    var nx = document.getElementById('txtn')
    var rx = document.getElementById('txtr')
    var res = document.querySelector('div#res')
    var an
    var soma
    if (a1x.value.length == 0 || nx.value.length == 0 || rx.value.length == 0) {
        window.alert('ERRO -> Dados incorretos!')
    } else if (nx.value == 0 || nx.value < 0) {
        window.alert('ERRO -> Se não há termos, não há progressão!')
    } else if (rx.value == 0) {
        window.alert('ERRO -> Uma progressão de razão 0 não é uma progressão!')
    } else {
        var a1 = Number(a1x.value)
        var n = Number(nx.value)
        var r = Number(rx.value)
        var cont = 1
        an = a1 + (n - 1) * r
        soma = ((a1 + an) * n) / 2
        res.innerHTML = `Último termo = ${an}</br>
        Soma de todos os termos = ${soma}</br>
        PA Detalhada:</br>`

        while (cont <= n) {
            
            if (cont == n) {
                res.innerHTML += `[${a1}].`
            } else {
                res.innerHTML += `[${a1}], `
            }
            a1 = a1 + r
            cont++
        }
        
    }