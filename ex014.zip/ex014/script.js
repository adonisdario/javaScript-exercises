function carregar() {
    var msg = window.document.getElementById('msg')
    var img = window.document.getElementById('imagem')
    var tempo = new Date()
    var hora = tempo.getHours()
    var minuto = tempo.getMinutes()
    msg.innerHTML = `Agora são ${hora} horas e ${minuto} minutos.`
    switch (hora) {
        case 0: //madrugada
            img.src = 'madrugada1.png'
            document.body.style.background = '#010418'
            break
        case 1:
            img.src = 'madrugada1.png'
            document.body.style.background = '#010418'
            break
        case 2:
            img.src = 'madrugada2.png'
            document.body.style.background = 'black'
            break
        case 3:
            img.src = 'madrugada2.png'
            document.body.style.background = 'black'
            break
        case 4:
            img.src = 'madrugada3.png'
            document.body.style. background = '#1a4055'
            break
        case 5:
            img.src = 'madrugada3.png'
            document.body.style. background = '#1a4055'
            break
        case 6: //manhã
            img.src = 'manha1.png'
            document.body.style. background = '#d7dfe1'
            break
        case 7:
            img.src = 'manha1.png'
            document.body.style. background = '#d7dfe1'
            break
        case 8:
            img.src = 'manha2.png'
            document.body.style. background = '#fdbb52'
            break
        case 9:
            img.src = 'manha2.png'
            document.body.style. background = '#fdbb52'
            break
        case 10:
            img.src = 'manha2.png'
            document.body.style. background = '#fdbb52'
            break
        case 11:
            img.src = 'manha3.png'
            document.body.style. background = '#c19846'
            break
        case 12: //tarde
            img.src = 'manha3.png'
            document.body.style. background = '#c19846'
            break
        case 13:
            img.src = 'tarde1.png'
            document.body.style. background = '#bc8852'
            break
        case 14:
            img.src = 'tarde2.png'
            document.body.style. background = '#7d7a09'
            break
        case 15:
            img.src = 'tarde2.png'
            document.body.style. background = '#7d7a09'
            break
        case 16:
            img.src = 'tarde3.png'
            document.body.style. background = '#d87b02'
            break
        case 17:
            img.src = 'tarde3.png'
            document.body.style. background = '#d87b02'
            break
        case 18: // noite
            img.src = 'noite1.png'
            document.body.style. background = '#0b6e71'
            break
        case 19:
            img.src = 'noite1.png'
            document.body.style. background = '#0b6e71'
            break
        case 20:
            img.src = 'noite2.png'
            document.body.style. background = '#3c6190'
            break
        case 21:
            img.src = 'noite2.png'
            document.body.style. background = '#3c6190'
            break
        case 22:
            img.src = 'noite3.png'
            document.body.style. background = '#062125'
            break
        case 23:
            img.src = 'noite3.png'
            document.body.style. background = '#062125'
            break
    }
}