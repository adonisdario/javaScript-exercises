function tabuada() {
    let num = document.getElementById('txtnum')
    //Lembrando que let e var tanto faz
    let tab = document.getElementById('cxtabuada')

    if (num.value.length == 0) {
        window.alert('Por favor, digite um número!')        
    } else {
        let n = Number(num.value)
        let c = 1
        tab.innerHTML = ''
        while (c <= 10) {
            let item = document.createElement('option')
            //Assim é feito um elemento do tipo option, para colocar as opções dentro do select
            item.text = `${n} x ${c} = ${n*c}`
            tab.appendChild(item);
            c++
        }
        
    }
}